#include<bits/stdc++.h>
using namespace std;

typedef long long ll;
vector<vector<ll>> graph;
vector<ll> colors;

ll WHITE = 0, GRAY = 1, BLACK = 2;

void dfs(ll node, ll &cnt, ll& ar) {
  colors[node] = GRAY;
  cnt++;
  for(auto ng: graph[node]) {
    if(colors[ng] == WHITE) {
      ar++;
      dfs(ng, cnt, ar);
    }
    else
      ar++;
  }
  colors[node] = BLACK;
}

void solve() {
  ll n, m;
  cin >> n >> m;
  graph.resize(n);
  for(ll e = 0; e < m; ++e) {
    ll u, v; cin >> u >> v;
    u--; v--;
    graph[u].push_back(v);
    graph[v].push_back(u);
  }
  colors.resize(n, WHITE);
  ll cc = 0;
  ll quitar = 0;
  for(ll i = 0; i < n; ++i) {
    if(colors[i] == WHITE) {
      ll cnt_nodos= 0;
      ll cnt_aristas= 0;
      dfs(i, cnt_nodos, cnt_aristas);
      cc++;
      cnt_aristas /= 2;
      if(cnt_aristas > (cnt_nodos - 1))
        quitar += cnt_aristas - (cnt_nodos - 1);
    }
  }
  if(cc == 1 and quitar == 0) {
    cout << "BOM\n";
    return;
  }

  ll anadir = cc - 1;
  cout << "RUIM " <<quitar << ' '<<  anadir;
}

int main() {
  solve();
  return 0;
}
