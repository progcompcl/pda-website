#include<bits/stdc++.h>
using namespace std;

typedef long long ll;
vector<vector<ll>> graph;
vector<ll> colors;
vector<ll> parents;
ll WHITE = 0, GRAY = 1, BLACK = 2;

ll inicio = -1;
ll fin = -1;

void dfs(ll node, ll parent) {
  colors[node] = GRAY;
  parents[node] = parent;
  for(auto ng: graph[node]) {
    if(colors[ng] == WHITE) {
      dfs(ng, node);
    }
    if(colors[ng] == GRAY and ng != parent) {
      inicio = node;
      fin = ng;
    }
  }
  colors[node] = BLACK;
}

void solve() {
  ll n, m;
  cin >> n >> m;
  graph.resize(n);
  for(ll e = 0; e < m; ++e) {
    ll u, v; cin >> u >> v;
    u--; v--;
    graph[u].push_back(v);
    graph[v].push_back(u);
  }
  colors.resize(n, WHITE);
  parents.resize(n, -2);

  for(ll i = 0; i < n; ++i) {
    if(colors[i] == WHITE) {
      dfs(i, -1);
    }
  }

  if(inicio == -1) {
    cout << "IMPOSSIBLE\n";
    return;
  }
 
  vector<ll> res;
  res.push_back(fin+1);
  ll actual = inicio;
  while(actual != fin) {
    res.push_back(actual+1);
    actual = parents[actual];
  }
  res.push_back(fin+1);

  cout << res.size() << '\n';
  for(auto r: res)
    cout << r << ' ';
  cout << '\n';

}

int main() {
  solve();
  return 0;
}
