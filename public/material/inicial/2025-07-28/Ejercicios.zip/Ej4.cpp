#include<bits/stdc++.h>
using namespace std;

typedef long long ll;
vector<string> grilla;

ll n, m;
vector<pair<ll, ll>> movs = {{-1, 0}, {1, 0}, {0, -1}, {0, 1}};

void bfs(ll i, ll j) {
  queue<pair<ll, ll>> q;
  q.push({i, j});
  while(!q.empty()) {
    auto [x,y] = q.front();
    q.pop();
    if(x < 0 or x >= n) continue;
    if(y < 0 or y >= m) continue;
    if(grilla[x][y] == '#') continue;
    grilla[x][y] = '#';
    for(auto [xx, yy]: movs) {
      q.push({x + xx, y + yy});
    }
  }
}

ll solve() {
  cin >> n >> m;
  grilla.resize(n);
  for(auto &s: grilla) 
    cin >> s;
  ll ans = 0;
  for(ll x = 0; x < n; ++x) {
    for(ll y = 0; y < m; ++y) {
      if(grilla[x][y] != '#') {
        ans++;
        bfs(x, y);
      }
    }
  }
  return ans;
}

int main() {
  ll t = 1;
  //cin >> t;
  while(t--)
    cout << solve() << '\n';
  return 0;
}
