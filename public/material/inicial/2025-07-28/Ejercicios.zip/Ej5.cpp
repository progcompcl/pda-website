#include<bits/stdc++.h>
using namespace std;

typedef long long ll;

vector<vector<ll>> graph;
vector<ll> dist;
vector<ll> parent;

void bfs(ll node) {
  //estamos contando la cantidad de nodos, no de aristas
  dist[node] = 1;
  parent[node] = -1;
  queue<ll> q;
  q.push(node);
  while(!q.empty()) {
    ll top = q.front();
    q.pop();
    for(auto ng: graph[top]) {
      if(dist[ng] > dist[top] + 1) {
        parent[ng] = top;
        dist[ng] = dist[top] + 1;
        q.push(ng);
      }
    }
  }
}

ll IMPOSSIBLE = 1'000'000'000'000;

void solve() {
  ll n, m;
  cin >> n >> m;
  graph.resize(n);
  dist.resize(n, IMPOSSIBLE);
  parent.resize(n, IMPOSSIBLE);
  //leo el grafo
  for(ll i = 0; i < m; ++i) {
    ll u, v; cin >> u >> v;
    //resto 1 en ambos, porque sus valores van de 1 a n
    u--; v--;
    //anado en ambas direcciones, porque es no dirigido
    graph[u].push_back(v);
    graph[v].push_back(u);
  }

  //ejecutar un dfs que me almacene el camino mas corto
  bfs(0);

  ll actual = n-1;
  if(dist[actual] == IMPOSSIBLE) {
    cout << "IMPOSSIBLE\n";
    return;
  }

  ll id = 0;
  vector<ll> path(dist[actual]);
  //imprimir resultado
  //tamano del camino
  cout << dist[actual] << '\n';
  //el camino
  while(parent[actual] != -1) {
    path[id] = actual + 1;
    actual = parent[actual];
    id++;
  }
  path[id] = actual + 1;
  reverse(path.begin(), path.end());
  for(auto node: path)
    cout << node << ' ';
  cout << '\n';
} 

int main() {
  //resuelvo un caso
  solve();
  return 0;
}
