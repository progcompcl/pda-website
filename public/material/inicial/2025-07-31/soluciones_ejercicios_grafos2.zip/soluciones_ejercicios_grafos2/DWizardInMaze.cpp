// Problem: D - Wizard in Maze
// Contest: AtCoderBeginnerContest176
// Judge: AtCoder
// URL: https://atcoder.jp/contests/abc176/tasks/abc176_d
// Memory Limit: 1024
// Time Limit: 2000
// Start: Wed 07 May 2025 05:36:16 PM -04

#include<bits/stdc++.h>

using namespace std;

typedef long long ll;
typedef pair<ll,ll> pl;
typedef vector<pl> vpl;
typedef vector<ll> vl;
typedef vector<vector<vpl>> vvpl;

#define FastIO() ios_base::sync_with_stdio(false); cin.tie(NULL)
#define all(x) x.begin(),x.end()
#define F first
#define S second

ll h,w;
ll ix,iy;
ll fx, fy;
vector<string> grid;
vvpl graph;
vector<vector<ll>> dis;

void bfs(pl cell) {
  dis[cell.F][cell.S] = 0;
  queue<pl> q;
  q.push(cell);
  while(!q.empty()) {
    pl top = q.front();
    q.pop();
    ll i = top.F;
    ll j = top.S;
    for(pl &p: graph[i][j]) {
      if(dis[p.F][p.S] > dis[i][j] + 1) {
        dis[p.F][p.S] = dis[i][j] + 1;
        q.push(p);
      }
    }
  }
}

bool valid(pl c) {
  ll i = c.F, j = c.S;
  if(i < 0 or i >= h) return false;
  if(j < 0 or j >= w) return false;
  if(grid[i][j] == '#') return false;
  return true;
}

class UnionFind {
  public:
    vector<vpl> fam;
    UnionFind(ll _h, ll _w) {
      fam.resize(_h, vpl(_w));
      for(ll i = 0; i < _h; ++i) {
        for(ll j = 0; j < _w; ++j) {
          fam[i][j] = {i,j};
        }
      }
    }

    pl find(pl cell) {
      ll i = cell.F;
      ll j = cell.S;
      return fam[i][j] == cell ? fam[i][j] : fam[i][j] = find(fam[i][j]);
    }

    void merge(pl c1, pl c2) {
      if(!valid(c1)) return;
      if(!valid(c2)) return;
      pl root1 = find(c1);
      pl root2 = find(c2);
      if(root1 != root2) {
        fam[root2.F][root2.S] = root1;
      }
    }
};

ll solve() {
  cin >> h >> w;
  cin >> ix >> iy;
  ix--; iy--;
  cin >> fx >> fy;
  fx--; fy--;
  UnionFind uf(h,w);
  grid.resize(h);
  
  //leo la grilla
  for(ll i = 0; i < h; ++i) {
    cin >> grid[i];
  }

  //creo el DSU con la grilla y movimientos basicos del mago
  for(ll i = 0; i < h; ++i) {
    for(ll j = 0; j < w; ++j) {
     if(grid[i][j] == '.') {
        uf.merge({i, j}, {i + 1, j});
        uf.merge({i, j}, {i - 1, j});
        uf.merge({i, j}, {i, j - 1});
        uf.merge({i, j}, {i, j + 1});
      }
    }
  }

  //si estan en la misma comp conexa,
  //no tenemos que usar magia
  if(uf.find({ix, iy}) == uf.find({fx,fy}))
    return 0;


  vl movX = {-2, -1, 0, 1, 2};
  vl movY = {-2, -1, 0, 1, 2};
  graph.resize(h, vector<vpl>(w));
  dis.resize(h, vl(w, 1e9));
  //creo un grafo nuevo con aristas a cualquier celda con distancia de 
  //a los mas 2 celdas, que no sea parte de mi comp conexa
  set<pair<pl,pl>> used;
  for(ll i = 0; i < h; ++i) {
    for(ll j = 0; j < w; ++j) {
      if(grid[i][j] == '#') continue;
      //por cada punto valido de la grilla
      //probamos los 25 posibles movimientos de magia
      //para crear el grafo
      for(ll mx = 0; mx < 5; ++mx) {
        for(ll my = 0; my < 5; ++my) {
          ll mxx = movX[mx];
          ll myy = movY[my];
          if(mxx == 0 and myy == 0) continue;
          if(!valid({i + mxx, j + myy})) continue;
          pl rootU = uf.find({i,j});
          pl rootV = uf.find({i+mxx,j+myy});
          //si detecto que usando magia, puedo llegar a otra comp conexa,
          //en el nuevo grafo, son una misma comp conexa y creo la
          //arista del nuevo grafo entre ambos nodos (que son las 
          //roots de cada UF).
          if(rootU != rootV and used.find({rootU,rootV}) == used.end()) {
            graph[rootU.F][rootU.S].push_back(rootV);
            graph[rootV.F][rootV.S].push_back(rootU);
            used.insert({rootU,rootV});
            used.insert({rootV,rootU});
          }
        }
      }
    }
  }

  //hago bfs para encontrar el camino minimo entre la celda 
  //[ix][iy] hasta la celda [fx][fy]
  bfs(uf.find({ix,iy}));
  pl rootf = uf.find({fx, fy});
  ll res = dis[rootf.F][rootf.S];
  return res == 1e9 ? -1 : res; 
}

int main() {
  FastIO();
  int t = 1;
  //cin >> t;
  while(t--) {
    cout << solve() << '\n'; 
  }
  return 0;
}
