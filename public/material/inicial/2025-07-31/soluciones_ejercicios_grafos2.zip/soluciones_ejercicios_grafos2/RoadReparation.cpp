#include <bits/stdc++.h>
using namespace std;

typedef long long ll;
typedef vector<ll> vl;
typedef vector<vl> vvl;
typedef pair<ll,ll> pl;
typedef vector<pl> vpl;
 
#define FastIO() ios_base::sync_with_stdio(false); cin.tie(NULL)
#define all(x) x.begin(),x.end()
#define F first
#define S second

struct UnionFind {
  vl conjuntos, elementos_size, conexiones_size;
  set<ll> representantes;
  UnionFind(ll n) {
    conjuntos.resize(n);
    for(ll i = 0; i < n; ++i) {
      representantes.insert(i);
      conjuntos[i] = i;
    }
    elementos_size.resize(n, 1);
    conexiones_size.resize(n, 0);
  }
  
  //saber a que conjunto pertenece un elemento
  ll Find(ll ele) {
    return conjuntos[ele] == ele ? ele : conjuntos[ele] = Find(conjuntos[ele]);
  }
  
  //dado dos elementos, unir los dos conjuntos, ssi son de conjuntos diferentes
  bool Union(ll ele1, ll ele2) {
    ll subc1 = Find(ele1);
    ll subc2 = Find(ele2);
    if(subc1 == subc2) {
      conexiones_size[subc1]++;
      return false;
    }
    conjuntos[subc2] = conjuntos[subc1];
    representantes.erase(subc2);
    elementos_size[subc1] += elementos_size[subc2];
    conexiones_size[subc1] += 1 + conexiones_size[subc2];
    return true;
  }
 
  ll n_elementos(ll ele) {
    ll subc = Find(ele);
    return elementos_size[subc];
  }
  
  ll n_conexiones(ll ele) {
    ll subc = Find(ele);
    return conexiones_size[subc];
  }
  
  ll n_representantes() {
    return (ll) representantes.size();
  }
};

void solve() {
  ll n, m; cin >> n >> m;
  UnionFind uf(n);
  vector<pair<ll, pl>> edge_rep(m);
  for(ll i = 0; i < m; ++i) {
    ll u, v, w; cin >> u >> v >> w;
    u--; v--;
    edge_rep[i] = {w, {u, v}};
    uf.Union(u, v);
  }
  if(uf.n_representantes() > 1) {
    cout << "IMPOSSIBLE\n";
    return;
  }
  sort(all(edge_rep));
  UnionFind uf2(n);
  ll cost = 0;
  for(auto [w, p]: edge_rep) {
    auto [u,v] = p;
    if(uf2.Union(u, v)) {
      cost += w;
    }
  }
  cout << cost << '\n';
}

int main () {
  FastIO();
  solve();
  return 0;
}
