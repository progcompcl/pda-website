// Problem: B. Map of the city
// Contest: MFP2025-FirstPhaseMirror
// Judge: Codeforces
// URL: https://codeforces.com/group/9CNwiex6Ir/contest/606592/problem/B
// Memory Limit: 256
// Time Limit: 1000
// Start: Tue 29 Apr 2025 08:01:09 PM -04

#include<bits/stdc++.h>

using namespace std;

typedef long long ll;
typedef vector<ll> vl;
typedef vector<vl> vvl;
typedef pair<ll,ll> pl;
typedef vector<pl> vpl;

#define FastIO() ios_base::sync_with_stdio(false); cin.tie(NULL)
#define all(x) x.begin(),x.end()
#define F first
#define S second

struct UnionFind {
  vl conjuntos, elementos_size, conexiones_size;
  set<ll> representantes;
  UnionFind(ll n) {
    conjuntos.resize(n);
    for(ll i = 0; i < n; ++i) {
      representantes.insert(i);
      conjuntos[i] = i;
    }
    elementos_size.resize(n, 1);
    conexiones_size.resize(n, 0);
  }
  
  //saber a que conjunto pertenece un elemento
  ll Find(ll ele) {
    return conjuntos[ele] == ele ? ele : conjuntos[ele] = Find(conjuntos[ele]);
  }
  
  //dado dos elementos, unir los dos conjuntos, ssi son de conjuntos diferentes
  bool Union(ll ele1, ll ele2) {
    ll subc1 = Find(ele1);
    ll subc2 = Find(ele2);
    if(subc1 == subc2) {
      conexiones_size[subc1]++;
      return false;
    }
    conjuntos[subc2] = conjuntos[subc1];
    representantes.erase(subc2);
    elementos_size[subc1] += elementos_size[subc2];
    conexiones_size[subc1] += 1 + conexiones_size[subc2];
    return true;
  }

  //retorna la cantidad de elementos de un conjunto
  ll n_elementos(ll ele) {
    ll subc = Find(ele);
    return elementos_size[subc];
  }
  
  //retorna la cantidad de conexiones de un conjunto
  ll n_conexiones(ll ele) {
    ll subc = Find(ele);
    return conexiones_size[subc];
  }

  //retorna la cantidad de representates activos en el UnionFind
  ll n_representantes() {
    return representantes.size();
  }
};

void solve() {
  ll n, m; cin >> n >> m;
  UnionFind uf(n);
  for(ll arista = 0; arista < m; ++arista) {
    ll u, v; cin >> u >> v;
    u--; v--;
    uf.Union(u, v);
  }

  ll quitar = 0; 
  ll anadir = (ll) uf.representantes.size() - 1;

  for(auto rep: uf.representantes) {
    quitar += uf.n_conexiones(rep) - (uf.n_elementos(rep) - 1);
  }
  
  if(anadir == 0 and quitar == 0) {
    cout << "BOM\n";
    return;
  }

  cout << "RUIM " << quitar << ' ' << anadir << '\n';
}

int main() {
  FastIO();
  int t = 1;
  //cin >> t;
  while(t--) {
    solve();
  }
  return 0;
}
