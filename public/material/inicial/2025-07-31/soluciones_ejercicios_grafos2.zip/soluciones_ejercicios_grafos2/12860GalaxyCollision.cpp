#include <bits/stdc++.h>
using namespace std;

#define ll long long

typedef pair<ll, ll> pl;
typedef vector<ll> vl;
typedef vector<pl> vpl;
typedef vector<vl> vvl;

ll distt(pl p1, pl p2) {
  auto [x1, y1] = p1;
  auto [x2, y2] = p2;
  return (x1 - x2)*(x1 - x2) + (y1 - y2)*(y1 - y2);
}

void dfs(ll node, vvl &graph, vector<bool> &vis, ll &s1, ll &s2, bool black = true) {
  vis[node] = true;
  if(black) s1++;
  else s2++;
  for(auto &ng: graph[node]) {
    if(!vis[ng]) {
      dfs(ng, graph, vis, s1, s2, !black);
    }
  }
}

int main() {
  ll n; 
  while(cin >> n) {
    map<pl, ll> points;
    for(ll i = 0; i < n; ++i) {
      ll x,y;
      cin >> x >> y;
      points[{x,y}] = i;
    }
    ll s1 = 0, s2 = 0;
    vvl graph(n);
    for(auto &[me, id]: points) {
      auto [x,y] = me;
      for(ll xx = -5; xx < 5; ++xx) {
        for(ll yy = -5; yy < 5; ++yy) {
          if(xx == 0 and yy == 0) continue;
          pl other = {x + xx, y + yy};
          ll dis = distt(me, other);
          if(dis <= 25LL and points.find(other) != points.end()) {
            ll id_other = points[other];
            graph[id].push_back(id_other);
            graph[id_other].push_back(id);
          }
        }
      }
    }
    vector<bool> vis(n);
    ll ans = 0;
    for(ll i = 0; i < n; ++i) {
      if(!vis[i]) {
        s1 = 0, s2 = 0;
        dfs(i, graph, vis, s1, s2);
        ans += min(s1, s2);
      }
    }
    cout << ans << '\n';
  }
  return 0;
}
