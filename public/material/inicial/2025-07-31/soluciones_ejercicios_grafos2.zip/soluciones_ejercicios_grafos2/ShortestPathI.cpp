#include <bits/stdc++.h>
using namespace std;

typedef long long ll;
vector<vector<pair<ll, ll>>> digraph;
vector<ll> dist;

ll oo = 1'000'000'000'000'000'000;

void dijkstra(ll node) {
  dist[node] = 0;
  priority_queue<pair<ll, ll>, vector<pair<ll,ll>>, greater<pair<ll,ll>>> pq;
  pq.push(make_pair(dist[node], node));
  while(!pq.empty()) {
    auto const [dist_top, top] = pq.top();
    pq.pop();
    if(dist_top > dist[top]) {
      continue;
    }
    for(auto const &[ng, w_wg]: digraph[top]) {
      if(dist[ng] > dist_top + w_wg) {
        dist[ng] = dist_top + w_wg;
        pq.push(make_pair(dist[ng], ng));
      }
    }
  }
}
#define FastIO() ios_base::sync_with_stdio(false); cin.tie(NULL)
void solve() {
  FastIO();
  ll n, m;
  cin >> n >> m;
  digraph.resize(n+1);
  dist.resize(n+1, oo);
  for(ll i = 0; i < m; ++i) {
    ll u, v, w; cin >> u >> v >> w;
    digraph[u].push_back(make_pair(v,w));
  }

  //desde 1, ya que hice que mis nodos vayan de 1 a n
  dijkstra(1);

  for(ll i = 1; i <= n; ++i)
    cout << dist[i] << ' ';
  cout << '\n';

}

int main() {
  solve();
  return 0;
}
