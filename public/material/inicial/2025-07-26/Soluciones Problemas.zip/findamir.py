n = int(input())
print((n+1)//2 -1)